#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include "BST.h"
#include "Student.h"

using namespace std;

bool readFile(const char* filename, BST* t1);
int menu();
void Option(int option, BST& t1);

int main() {
    BST t1;
    int choice;
    do {
        choice = menu();
        system("cls");
        Option(choice, t1);
    } while (choice != 7);
    cin.ignore();
    return 0;
}

// Function to read student records from a file and store them in a BST
bool readFile(const char* filename, BST* t1) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open file." << endl;
        return false;
    }

    Student student;
    char buffer[256];
    int count = 0;

    while (file.getline(buffer, sizeof(buffer))) {
        // Find the '=' character
        char* key = strtok(buffer, "=");
        char* value = strtok(nullptr, "");

        if (key && value) {
            value = value + 1;  // Skip the space after '='

            if (strstr(key, "Student Id") != nullptr) {
                student.id = atoi(value);
            }
            else if (strstr(key, "Name") != nullptr) {
                strncpy(student.name, value, sizeof(student.name) - 1);
                student.name[sizeof(student.name) - 1] = '\0';
            }
            else if (strstr(key, "Address") != nullptr) {
                strncpy(student.address, value, sizeof(student.address) - 1);
                student.address[sizeof(student.address) - 1] = '\0';
            }
            else if (strstr(key, "DOB") != nullptr) {
                strncpy(student.DOB, value, sizeof(student.DOB) - 1);
                student.DOB[sizeof(student.DOB) - 1] = '\0';
            }
            else if (strstr(key, "Phone Number") != nullptr) {
                strncpy(student.phone_no, value, sizeof(student.phone_no) - 1);
                student.phone_no[sizeof(student.phone_no) - 1] = '\0';
            }
            else if (strstr(key, "Course") != nullptr) {
                strncpy(student.course, value, sizeof(student.course) - 1);
                student.course[sizeof(student.course) - 1] = '\0';
            }
            else if (strstr(key, "CGPA") != nullptr) {
                student.cgpa = atof(value);
                t1->insert(student);
                count++;
            }
        }
    }

    cout << "Number of student records read: " << count << endl;
    file.close();
    return true;
}

int menu() {
    int choice;
    cout << "\nMenu:\n";
    cout << "1) Read data to BST\n";
    cout << "2) Print deepest nodes\n";
    cout << "3) Display student\n";
    cout << "4) Clone Subtree\n";
    cout << "5) Print Level Nodes\n";
    cout << "6) Print Path\n";
    cout << "7) Exit\n";
    cout << "Enter your choice: ";
    cin >> choice;
    if (cin.fail())
    {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    return choice;
}

void Option(int option, BST& t1) {
    switch (option) {
    case 1: {
        const char* filename = "student.txt";
        readFile(filename, &t1);
        break;
    }
    case 2: {
        if (t1.deepestNodes()) {
            cout << "Deepest nodes printed successfully." << endl;
        }
        else {
            cout << "Tree is empty." << endl;
        }
        break;
    }
    case 3: {
        int order, source;
        cout << "Enter order (1 for ascending, 2 for descending): ";
        cin >> order;
        while (cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid Input" << endl;
            cout << "Enter order (1 for ascending, 2 for descending): ";
            cin >> order;
        }
        cout << "Enter source (1 for screen, 2 for file): ";
        cin >> source;
        while(cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid Input" << endl;
            cout << "Enter source (1 for screen, 2 for file): ";
            cin >> source;
        }
        if (t1.display(order, source)) {
            cout << "Display successful." << endl;
        }
        else {
            cout << "Tree is empty." << endl;
        }
        break;
    }
    case 4: {
        int item;
        cout << "Enter the root value for the subtree to clone: ";
        cin >> item;
        while (cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid Input" << endl;
            cout << "Enter the root value for the subtree to clone: ";
            cin >> item;
        }
        Student student;
        student.id = item; // assign input to student.id

        BST t2;
        if (t2.CloneSubtree(t1, student)) {  // Pass the integer item instead of the student object
            cout << "Subtree cloned successfully." << endl;
            cout << "Original Tree (t1):" << endl;
            t1.preOrderPrint();
            cout << "Cloned Subtree (t2):" << endl;
            t2.preOrderPrint();
        }
        else {
            cout << "Cannot clone subtree." << endl;
        }
        break;
    }
    case 5: {
        if (t1.printLevelNodes()) {
            cout << endl;
            cout << "Level nodes printed successfully." << endl;
        }
        else {
            cout << "Tree is empty." << endl;
        }
        break;
    }
    case 6: {
        if (t1.printPath()) {
            cout << endl;
            cout << "Paths printed successfully." << endl;
        }
        else {
            cout << "Tree is empty." << endl;
        }
        break;
    }
    case 7:
        cout << "Exiting program." << endl;
        break;
    default:
        cout << "Invalid option. Please try again." << endl;
    }
}
