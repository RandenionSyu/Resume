#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <algorithm>
#include "BST.h"


using namespace std;


BST::BST() {
	root = NULL;
	count = 0;
}


bool BST::empty() {
	if (count == 0) return true;
	return false;
}


int BST::size() {
	return count;
}


void BST::preOrderPrint() {
	if (root == NULL) return;// handle special case
	else preOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::preOrderPrint2(BTNode *cur) {

	if (cur == NULL) return;
	cur->item.print(cout);
	preOrderPrint2(cur->left);
	preOrderPrint2(cur->right);
}


void BST::inOrderPrint() {
	if (root == NULL) return;// handle special case
	else inOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::inOrderPrint2(BTNode *cur) {

	if (cur == NULL) return;

	inOrderPrint2(cur->left);
	cur->item.print(cout);
	inOrderPrint2(cur->right);
}


void BST::postOrderPrint() {
	if (root == NULL) return;// handle special case
	else postOrderPrint2(root);// do normal process
	cout << endl;
}


void BST::postOrderPrint2(BTNode *cur) {
	if (cur == NULL) return;
	postOrderPrint2(cur->left);
	postOrderPrint2(cur->right);
	cur->item.print(cout);
}



int BST::countNode() {
	int	counter = 0;
	if (root == NULL) return 0;
	countNode2(root, counter);
	return counter;
}


void BST::countNode2(BTNode *cur, int &count) {
	if (cur == NULL) return;
	countNode2(cur->left, count);
	countNode2(cur->right, count);
	count++;
}


bool BST::findGrandsons(type grandFather) {
	if (root == NULL) return false;
	return (fGS2(grandFather, root));
}


bool BST::fGS2(type grandFather, BTNode *cur) {
	if (cur == NULL) return false;
	//if (cur->item == grandFather) {
	if (cur->item.compare2(grandFather)){

		fGS3(cur, 0);// do another TT to find grandsons
		return true;
	}
	if (fGS2(grandFather, cur->left)) return true;
	return fGS2(grandFather, cur->right);
}


void BST::fGS3(BTNode *cur, int level) {
	if (cur == NULL) return;
	if (level == 2) {
		cur->item.print(cout);
		return;  // No need to search downward
	}
	fGS3(cur->left, level + 1);
	fGS3(cur->right, level + 1);
}



void BST::topDownLevelTraversal() {
	BTNode			*cur;
	Queue		    q;


	if (empty()) return; 	// special case
	q.enqueue(root);	// Step 1: enqueue the first node
	while (!q.empty()) { 	// Step 2: do 2 operations inside
		q.dequeue(cur);
		if (cur != NULL) {
			cur->item.print(cout);

			if (cur->left != NULL)
				q.enqueue(cur->left);

			if (cur->right != NULL)
				q.enqueue(cur->right);
		}
	}
}
bool BST::exists(BTNode* node, const type& newItem) {
	if (node == NULL) return false;  // Base case: reached a leaf, item not found

	// Compare the current node's item with the new item
	if (node->item.compare2(newItem)) {
		return true;  // Item already exists in the tree
	}
	else if (node->item.compare1(newItem)) {
		// Continue searching in the left subtree
		return exists(node->left, newItem);
	}
	else {
		// Continue searching in the right subtree
		return exists(node->right, newItem);
	}
}
//insert for BST
bool BST::insert(type newItem) {
	// Check if the item already exists
	if (exists(root, newItem)) {
		cout << "Item with ID " << newItem.id << " already exists. Duplicate insertion not allowed." << endl;
		return false;  // Duplicate found, do not insert
	}
	BTNode	*cur = new BTNode(newItem);
	if (!cur) return false;		// special case 1
	if (root == NULL) {
		root = cur;
		count++;
		return true; 			// special case 2
	}
	insert2(root, cur);			// normal
	count++;
	return true;
}


void BST::insert2(BTNode *cur, BTNode *newNode) {
	//if (cur->item > newNode->item) {
	if (cur->item.compare1(newNode->item)){
		if (cur->left == NULL)
			cur->left = newNode;
		else
			insert2(cur->left, newNode);
	}
	else {
		if (cur->right == NULL)
			cur->right = newNode;
		else
			insert2(cur->right, newNode);
	}
}



bool BST::remove(type item) {
	if (root == NULL) return false; 		// special case 1: tree is empty
	return remove2(root, root, item); 		// normal case
}

bool BST::remove2(BTNode *pre, BTNode *cur, type item) {

	// Turn back when the search reaches the end of an external path
	if (cur == NULL) return false;

	// normal case: manage to find the item to be removed
	//if (cur->item == item) {
	if (cur->item.compare2(item)){
		if (cur->left == NULL || cur->right == NULL)
			case2(pre, cur);	// case 2 and case 1: cur has less than 2 sons
		else
			case3(cur);		// case 3, cur has 2 sons
		count--;				// update the counter
		return true;
	}

	// Current node does NOT store the current item -> ask left sub-tree to check
	//if (cur->item > item)
	if (cur->item.compare1(item))
		return remove2(cur, cur->left, item);

	// Item is not in the left subtree, try the right sub-tree instead
	return remove2(cur, cur->right, item);
}


void BST::case2(BTNode *pre, BTNode *cur) {

	// special case: delete root node
	if (pre == cur) {
		if (cur->left != NULL)	// has left son?
			root = cur->left;
		else
			root = cur->right;

		free(cur);
		return;
	}

	if (pre->right == cur) {		// father is right son of grandfather? 
		if (cur->left == NULL)			// father has no left son?
			pre->right = cur->right;			// connect gfather/gson
		else
			pre->right = cur->left;
	}
	else {						// father is left son of grandfather?
		if (cur->left == NULL)			// father has no left son? 
			pre->left = cur->right;				// connect gfather/gson
		else
			pre->left = cur->left;
	}

	free(cur);					// remove item
}


void BST::case3(BTNode *cur) {
	BTNode		*is, *isFather;

	// get the IS and IS_parent of current node
	is = isFather = cur->right;
	while (is->left != NULL) {
		isFather = is;
		is = is->left;
	}

	// copy IS node into current node
	cur->item = is->item;

	// Point IS_Father (grandfather) to IS_Child (grandson)
	if (is == isFather)
		cur->right = is->right;		// case 1: There is no IS_Father    
	else
		isFather->left = is->right;	// case 2: There is IS_Father

	// remove IS Node
	free(is);
}

// Helper function for ascending order traversal (in-order)
void BST::inOrderTraversal(BTNode* node, std::ostream& os) {
	if (node == NULL) return;

	inOrderTraversal(node->left, os);  // Visit left subtree
	node->item.print(os);              // Print current node
	inOrderTraversal(node->right, os); // Visit right subtree
}

// Helper function for descending order traversal
void BST::descendingOrderTraversal(BTNode* node, std::ostream& os) {
	if (node == NULL) return;

	descendingOrderTraversal(node->right, os); // Visit right subtree first
	node->item.print(os);                      // Print current node
	descendingOrderTraversal(node->left, os);  // Visit left subtree last
}

// Main display function
bool BST::display(int order, int source) {
	if (root == NULL) {
		cout << "The tree is empty." << endl;
		return false;
	}

	std::ofstream outFile;
	if (source == 2) {
		outFile.open("student-info.txt");
		if (!outFile) {
			cout << "Error opening file." << endl;
			return false;
		}
	}

	std::ostream& output = (source == 1) ? std::cout : outFile;

	if (order == 1) {
		// Ascending order traversal
		inOrderTraversal(root, output);
	}
	else if (order == 2) {
		// Descending order traversal
		descendingOrderTraversal(root, output);
	}
	else {
		cout << "Invalid order parameter." << endl;
		return false;
	}

	if (source == 2) {
		outFile.close();
		cout << "Student information has been written to student-info.txt" << endl;
	}

	return true;
}


// Helper function to find the node containing the item
BTNode* BST::findNode(BTNode* node, const Student& student) {
	if (node == NULL) return NULL;

	if (node->item.id == student.id) {
		return node;  // Found the node
	}
	else if (student.id < node -> item.id) {
		return findNode(node->left, student);  // Search in the left subtree
	}
	else {
		return findNode(node->right, student); // Search in the right subtree
	}
}

// Helper function to clone a subtree
BTNode* BST::cloneSubtree(BTNode* node) {
	if (node == NULL) return NULL;

	BTNode* newNode = new BTNode(node->item);  // Create a new node with the same item
	newNode->left = cloneSubtree(node->left);  // Recursively clone the left subtree
	newNode->right = cloneSubtree(node->right);// Recursively clone the right subtree
	return newNode;
}

// Main function to clone the subtree
bool BST::CloneSubtree(BST t1, type item) {
	if (t1.root == NULL) {
		cout << "Cannot clone subtree: t1 is empty." << endl;
		return false;
	}

	// Find the node containing the item in t1
	BTNode* targetNode = t1.findNode(t1.root, item);

	if (targetNode == NULL) {
		cout << "Item not found." << endl;
		return false;
	}

	// Ensure t2 is empty
	if (this ->root != NULL) {
		cout << "t2 is not empty." << endl;
		return false;
	}

	// Clone the subtree and set it as the root of t2
	this->root = cloneSubtree(targetNode);
	this->count = t1.countNode();  // Update the node count in t2

	// Display the trees
	cout << "t1 (Original Tree):" << endl;
	t1.preOrderPrint();

	cout << "t2 (Cloned Subtree):" << endl;
	this->preOrderPrint();

	return true;
}


bool BST::deepestNodes() {
	if (root == nullptr) return false;

	int maxDepth = findMaxDepth(root);
	findDeepestNodes(root, 0, maxDepth);

	cout << endl;
	return true;
}

// Helper function to find the maximum depth of the tree
int BST::findMaxDepth(BTNode* node) {
	if (node == nullptr) return 0;

	int leftDepth = findMaxDepth(node->left);
	int rightDepth = findMaxDepth(node->right);

	return max(leftDepth, rightDepth) + 1;

}

// Helper function to print nodes at the deepest level
void BST::findDeepestNodes(BTNode* node, int depth, int maxDepth) {
	if (node == nullptr) return;

	if (depth == maxDepth - 1) {
		cout << node->item.id << " ";

	}

	findDeepestNodes(node->left, depth + 1, maxDepth);
	findDeepestNodes(node->right, depth + 1, maxDepth);

}

bool BST::printLevelNodes() {
	int n = 1;
	if (root == NULL) return false;
	else {
		cout << "Printing the Level:" << endl;
		cout << endl;
		printLevelNodes2(root);
		return true;
	}
}
bool BST::printLevelNodes2(BTNode* cur) {
	Queue q1, q2;
	int n = 1;
	q1.enqueue(cur);
	while (!q1.empty() || !q2.empty()) {
		cout << " Level " << n << " : ";
		while (!q1.empty()) {
			q1.dequeue(cur);
			if (cur != NULL) {
				cout << "  " << cur->item.id << "  ";

				if (cur->left != NULL)
					q2.enqueue(cur->left);

				if (cur->right != NULL)
					q2.enqueue(cur->right);
			}
		}
		n++;
		cout << endl;
		cout << " Level " << n << " : ";
		while (!q2.empty()) {
			q2.dequeue(cur);
			if (cur != NULL) {
				cout << "  " << cur->item.id << "  ";

				if (cur->left != NULL)
					q1.enqueue(cur->left);

				if (cur->right != NULL)
					q1.enqueue(cur->right);
			}
		}
		n++;
		cout << endl;
	}

	return true;
}
bool BST::printPath() {
	string num;
	if (root == NULL) return false;
	else {
		int path[100];
		cout << "Printing all external Path : " << endl;
		cout << endl;
		printPath2(root, path, 0);
		return true;
	}
}
void BST::printPath2(BTNode* cur, int arr[], int num) {
	if (cur == NULL) {
		return;
	}
	arr[num] = cur->item.id;
	num++;
	if (cur->left == NULL && cur->right == NULL)
	{
		for (int i = 0; i < num; i++)
		{
			cout << arr[i] << " ";
		}
		cout << endl;
		return;
	}
	printPath2(cur->left, arr, num);
	printPath2(cur->right, arr, num);
}