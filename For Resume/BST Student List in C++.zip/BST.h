#ifndef BT_type
#define BT_type

#include	"BTNode.h"
#include	"Queue.h"


struct BST {

		int		count;
		BTNode	*root;

		// print operation for BST (same as BT)					
		void preOrderPrint2(BTNode *);	// recursive function for preOrderPrint()
		void inOrderPrint2(BTNode *);	// recursive function for inOrderPrint()
		void postOrderPrint2(BTNode *);	// recursive function for postOrderPrint()

		// sample operation (extra functions) - same as BT
		void countNode2(BTNode *, int &);		// recursive function for countNode()
		bool fGS2(type, BTNode *);					// recursive function for findGrandsons(): to find the grandfather
		void fGS3(BTNode *, int);				// recursive function for findGrandsons(): to find the grandsons after the grandfather has been found
		
		// basic functions for BST
		void insert2(BTNode *, BTNode *);		// recursive function for insert() of BST
		void case3(BTNode *);					// recursive function for remove()
		void case2(BTNode *, BTNode *);		// recursive function for remove()
		bool remove2(BTNode *, BTNode *, type);	// recursive function for remove()
		bool exists(BTNode* node, const type& newItem); // Function to check if an item already exists


		// basic functions for BST
		BST();
		bool empty();
		int size();
		bool insert (type);		// insert an item into a BST
		bool remove(type);			// remove an item from a BST
		
		// print operation for BST (same as BT)
		void preOrderPrint();			// print BST node in pre-order manner
		void inOrderPrint();			// print BST node in in-order manner
		void postOrderPrint();			// print BST node in post-order manner
		void topDownLevelTraversal();	// print BST level-by-level

		// sample operation (extra functions) - same as BT
		int countNode();		// count number of tree nodes
		bool findGrandsons(type);	// find the grandsons of an input father item

		void inOrderTraversal(BTNode* node, std::ostream& os);
		void descendingOrderTraversal(BTNode* node, std::ostream& os);
		bool display(int order, int source);


		bool deepestNodes(); // Find and print the deepest nodes in the BST
		int findMaxDepth(BTNode* node); // Helper function to find the maximum depth of the tree
		void findDeepestNodes(BTNode* node, int depth, int maxDepth);


		BTNode* findNode(BTNode* node, const type& item);
		BTNode* cloneSubtree(BTNode* node);
		bool CloneSubtree(BST t1, type item);


		bool printLevelNodes();
		bool printLevelNodes2(BTNode* cur);
		bool printPath();
		void printPath2(BTNode* cur, int arr[], int num);
	
};




#endif